
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="py-4">
		<section id="plant-list">
			<div class="container">
			
            <?php if(count($reviews)==0 | empty($reviews)): ?>
			<h2>No Results</h2>
                
			<?php else: ?>
			<h4 class="card-title color-warning">Reviews</h4>
				<div class="table-responsive">
				<table class="table table-striped" style="table-layout: fixed;">
					<thead>
						<th scope="col">Review</th>
						<th scope="col">Rating</th>
						<th scope="col">Visible</th>
						<th scope="col">Related Order</th>
						<th scope="col">&nbsp;</th>
						<th scope="col">&nbsp;</th>
					</thead>
                    <tbody>
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td scope="row" style="overflow:hidden"><?php echo e($review->review); ?></td>
							<td scope="row" style="overflow:hidden"><?php echo e($review->rating); ?>/5</td>
							<td scope="row" style="overflow:hidden">
							<?php if(\App\Models\Orders::where('order_sn',$review->order_sn)->first()->shipped): ?>
								Yes
							<?php else: ?>
								No
							<?php endif; ?>
							</td>
							<td scope="row" style="overflow:hidden"><?php echo e($review->order_sn); ?></td>
							<td >
                            <form action="<?php echo e(url('/dashboard/reviews/'.$review->id)); ?>" method="GET">
									<?php echo e(csrf_field()); ?>

									 	<button type="submit" class="btn btn-success">
											<i class="glyphicon glyphicon-file"></i>Details
									 </button>
								 </form>
                            </td>
                            <td >
                            <form action="<?php echo e(url('/dashboard/reviews/showorder/'.$review->order_sn)); ?>" method="GET">
									<?php echo e(csrf_field()); ?>

									 	<button type="submit" class="btn btn-info">
											<i class="glyphicon glyphicon-file"></i>To Order
									 </button>
								 </form>
                            </td>
                            <td >
                            <form action="<?php echo e(url('/dashboard/reviews/'.$review->id)); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

									 	<button type="submit" class="btn btn-danger">
											<i class="glyphicon glyphicon-file"></i>Delete
									 </button>
								 </form>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

					
				</table>
			</div>
				<?php echo e($reviews->appends(Request::all())->links("pagination::bootstrap-4")); ?>

               
                <?php endif; ?>
			</div>
		</section>
		</div>
<?php echo $__env->make('layouts.nafs_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>