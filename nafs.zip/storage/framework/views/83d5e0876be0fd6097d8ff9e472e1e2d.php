  
  <?php echo $__env->make('layouts.navigation_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Hero Start -->
    <section class="product">
            <img src="product-image.jpg" alt="Product Name">
            <h2>Product Name</h2>
            <p class="price">$99.99</p>
            <button class="add-to-cart">Add to Cart</button>
        </section>
    
    
    <!-- Team End -->

    

   

    

   
  

  


<?php echo $__env->make('layouts.nafs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/nafs/index.blade.php ENDPATH**/ ?>