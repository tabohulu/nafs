 <!-- Topbar Start -->
 
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid sticky-top bg-white shadow-sm">
      <div class="container">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
          <a href="/" class="navbar-brand" target="_blank">
            <img src="/img/HClogo.jpg" alt="Logo" />
            <!-- <h1 class="m-0 text-uppercase text-primary">
              <i class="fa fa-clinic-medical me-2"></i>Medinova
            </h1> -->
          </a>
          
                <a class="nav-item nav-link"href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">Logout</a>
                
            
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ms-auto py-0">
              <li style="list-style: none;"><a href="/admin" class="nav-item nav-link <?php if($menu==1): ?> active <?php endif; ?>">予約</a></li>
              <li style="list-style: none;"><a href="/admin/seminars" class="nav-item nav-link <?php if($menu==2): ?> active <?php endif; ?>">セミナー</a></li>
              <li style="list-style: none;"><a href="/admin/products" class="nav-item nav-link <?php if($menu==3): ?> active <?php endif; ?>">健康商品</a></li>
              <li style="list-style: none;"><a href="/admin/services" class="nav-item nav-link <?php if($menu==7): ?> active <?php endif; ?>">健康サービス</a></li>
              <li style="list-style: none;"><a href="/admin/staffinfo" class="nav-item nav-link <?php if($menu==4): ?> active <?php endif; ?>">社員情報</a></li>
              <li style="list-style: none;"><a href="/admin/announcements" class="nav-item nav-link <?php if($menu==5): ?> active <?php endif; ?>">お知らせ</a></li>
              <li style="list-style: none;"><a href="/admin/members" class="nav-item nav-link <?php if($menu==6): ?> active <?php endif; ?>">会員制</a></li>
              <li style="list-style: none;"><a href="/admin/settings" class="nav-item nav-link <?php if($menu==8): ?> active <?php endif; ?>">その他</a></li>
            </ul>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
              </form>
          </div>
        </nav>
              <?php if($menu==1): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin">カレンダー</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/reservations">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/reservations/create">休み</a></li>
                    </ul>
                </div>
                <?php elseif($menu==2): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/seminars">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/seminars/create">新規</a></li>
                    </ul>
                </div>
                <?php elseif($menu==3): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/products">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/products/create">新規</a></li>
                    </ul>
                </div>
                <?php elseif($menu==7): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/services">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/services/create">新規</a></li>
                    </ul>
                </div>
                <?php elseif($menu==4): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/staffinfo">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/staffinfo/create">新規</a></li>
                    </ul>
                </div>
                <?php elseif($menu==5): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/announcements">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/announcements/create">新規</a></li>
                    </ul>
                </div>
                <?php elseif($menu==6): ?>
                <div class="card-title">
                    <ul class="row" style="list-style: none;">
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-2"></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/members">一覧</a></li>
                        <li style="list-style: none;" class="col-sm-1"><a href="/admin/members/create">新規</a></li>
                    </ul>
                </div>
                <hr>
                <?php endif; ?>
      </div>
    </div>
    <!-- Navbar End -->

    <?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/components/nav/adminbar.blade.php ENDPATH**/ ?>