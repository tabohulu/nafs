
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(url('/dashboard/reviews/'.$review->id.'/edit')); ?>" method="GET">
<?php echo e(csrf_field()); ?>

    <div class="container">
      <div class="row card-body">
      <h4 class="card-title color-warning" >Review  rated <?php echo e($review->rating); ?>/5  stars for <?php echo e($product->name); ?>, <span class="color-success " ><?php echo e($product->variety); ?>, <?php if($product->size/(1000)<1): ?><?php echo e($product->size); ?>ml <?php else: ?><?php echo e($product->size/(1000)); ?>L <?php endif; ?></span> by <?php echo e($review->order_sn); ?> </h4>
      <a href="/dashboard/reviews">To Reviews</a>  
      <hr>
        <div class="col-lg-3 pull-lg-8">
                            <div class="flexslider" data-controlnav="thumbnails">
                                <ul class="slides">

                                    <li data-thumb="/img/products/<?php echo e($product->img); ?>">
                                        <img class="prod-pic" src="/img/products/<?php echo e($product->img); ?>">
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="col pl-lg-9 push-lg-4">
        <div id="review_div" >



<div class="form-group row">
    

    <div class="col-sm-12">
        
        <div class="input-group mb-3">
        <textarea name="review" id="review" cols="80" rows="5" disabled>

        <?php echo e($review->review); ?>

        </textarea>
            
           


        </div>
    </div>

    

    

    
</div>


</div>
      </div>
     
      
      </div>
      

        
    </div>

      
</form>


       
      

    


<?php echo $__env->make('layouts.nafs_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/admin/reviews/show.blade.php ENDPATH**/ ?>