<!-- Topbar Start -->
<div class="container-fluid py-2 border-bottom d-none d-lg-block">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center text-lg-start mb-2 mb-lg-0">
            <div class="d-inline-flex align-items-center">
              <a class="text-decoration-none text-body pe-3" href="#">
                <i class="bi bi-telephone me-2"></i></a>
                
              <span class="text-body">|</span>

              <a class="text-decoration-none text-body px-3" href="#">
                <i class="bi bi-envelope me-2"></i></a>

                <span class="text-body">|</span>

              <div class="text-body px-3" href=""
                >平日　 <br>
                土日　
                </div>
                
                <a
                href="/appointment"
                class="btn btn-primary "
                >予約フォーム</a>
            </div>
          </div>
          <!-- <div class="col-md-6 text-center text-lg-end">
            <div class="d-inline-flex align-items-center">
              <a class="text-body px-2" href="">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a class="text-body px-2" href="">
                <i class="fab fa-twitter"></i>
              </a>
              <a class="text-body px-2" href="">
                <i class="fab fa-linkedin-in"></i>
              </a>
              <a class="text-body px-2" href="">
                <i class="fab fa-instagram"></i>
              </a>
              <a class="text-body ps-2" href="">
                <i class="fab fa-youtube"></i>
              </a>
            </div>
          </div> -->
        </div>
      </div>
    </div>
    <!-- Topbar End -->
<nav class="navbar navbar-expand-sm bg-white navbar-light py-3 py-lg-0 sticky-top">

<!-- <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0"> -->

  <div class="collapse navbar-collapse container-fluid bg-white">
  <a href="/" class="navbar-brand">
            <img src="/img/HClogo.jpg" alt="Logo" />
          </a>
    <!-- Links -->
    

    <ul class="navbar-nav ms-auto">
    <li style="list-style: none;" class="nav-item">
    <a href="/" class="nav-link ">Home</a>
    </li>
    <li class="nav-item" style="list-style: none; margin-left:10px"><a href="/shop"     class="nav-link ">Shop</a></li>
    <li class="nav-item" style="list-style: none; margin-left:10px"><a href="/about"     class="nav-link">About Us</a></li>
    <li class="nav-item" style="list-style: none; margin-left:10px"><a href="/contact"      class="nav-link ">Contact</a></li>
    </ul>
  </div>

</nav><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/components/nav/navbar2.blade.php ENDPATH**/ ?>