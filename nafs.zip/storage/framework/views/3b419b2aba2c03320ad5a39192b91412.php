
<?php echo $__env->make('layouts.navigation_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="pt-6 pb-4">
    <div class="container">
    <h1 class="fs-3 mb-3 fw-400 text-center" style="color:green">Review Successfully Received!<p style="color:red"></h1>
    <p class="text-center">Thank you for making the time. Page will be redirected to <a href="/">Home</a> 
    </p>   
        <h1 class="fs-3 mb-3 fw-400 text-center">Your <?php echo e($review->rating); ?> Star Review</h1>
    </div>
    <!--/.container-->
</section>
<div class="form-group row">
    
<div class="col-sm-2"></div>
    <div class="col-sm-8">
        
        <div class="input-group mb-3">
        <textarea name="review" id="review" cols="80" rows="5" disabled>

        <?php echo e($review->review); ?>

        </textarea>
            
           


        </div>
    </div>
    <div class="col-sm-2"></div>
    
</div>
<script type="text/javascript">
    document.addEventListener("DOMContentLoaded",()=>{
        setTimeout(()=>{
            window.location.href='/'
        }, 5000);
    })
        
         
      
    
</script>
<?php echo $__env->make('layouts.nafs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/nafs/review_confirm.blade.php ENDPATH**/ ?>