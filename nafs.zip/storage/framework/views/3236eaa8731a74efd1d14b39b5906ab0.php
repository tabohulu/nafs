
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="py-4">
		<section id="plant-list">
			<div class="container">
			
            <?php if(count($products)==0 | empty($products)): ?>
			<h2>No Results</h2>
                
			<?php else: ?>
			<h4 class="card-title color-warning">Products</h4>
				<div class="table-responsive">
				<table class="table table-striped" style="table-layout: fixed;">
					<thead>
						<th scope="col">Product Name</th>
						<th scope="col">Price</th>
						<th scope="col">Stock</th>
						<th scope="col">&nbsp;</th>
						<th scope="col">&nbsp;</th>
						<th scope="col">&nbsp;</th>
					</thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td scope="row" style="overflow:hidden"><?php echo e($product->name); ?></td>
							<td scope="row" style="overflow:hidden"><?php echo e($product->price); ?></td>
							<td scope="row" style="overflow:hidden"><?php echo e($product->stock_status); ?></td>
							<td >
                            <form action="<?php echo e(url('/dashboard/products/'.$product->id)); ?>" method="GET">
									<?php echo e(csrf_field()); ?>

									 	<button type="submit" class="btn btn-success">
											<i class="glyphicon glyphicon-file"></i>Details
									 </button>
								 </form>
                            </td>
                            <td >
                            <form action="<?php echo e(url('/dashboard/products/'.$product->id.'/edit')); ?>" method="GET">
									<?php echo e(csrf_field()); ?>

									 	<button type="submit" class="btn btn-info">
											<i class="glyphicon glyphicon-file"></i>Edit
									 </button>
								 </form>
                            </td>
                            <td >
                            <form action="<?php echo e(url('/dashboard/products/'.$product->id)); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

									 	<button type="submit" class="btn btn-danger">
											<i class="glyphicon glyphicon-file"></i>Delete
									 </button>
								 </form>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

					
				</table>
			</div>
				<?php echo e($products->appends(Request::all())->links("pagination::bootstrap-4")); ?>

               
                <?php endif; ?>
			</div>
		</section>
		</div>
<?php echo $__env->make('layouts.nafs_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/admin/products/index.blade.php ENDPATH**/ ?>