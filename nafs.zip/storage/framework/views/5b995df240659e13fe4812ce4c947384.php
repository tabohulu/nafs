
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(url('/dashboard/products/'.$products->id)); ?>" method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>

    <div class="container">
    <div class="card-body">
      <h4 class="card-title color-warning" >Products</h4>
        <hr>
        <div class="form-group row">
          <label for="img" class="col-sm-2 col-form-label">Image</label>
          <div class="col-sm-5">
            <label class="btn btn-success" for="img">Select</label>
          <input type="text" id ="old_img" name ="old_img" readonly value="<?php echo e($products->img); ?>" />
          <input type="file" id ="img" name="img" accept="image/png, image/gif, image/jpeg"  style="display: none;"/>
          </div>
          
          

          <div class="col-sm-5">
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <label class="input-group-text" for="name">Product Name</label>
              </div>
              <input type="text" name="name" id="name" class="form-control" value="<?php echo e($products->name); ?>">
            </div>
          </div>

        </div>

        <div class="form-group row">
        <label for="img" class="col-sm-2 col-form-label">Variety</label>
        <div class="col-sm-4">
        <input type="text" name="variety" id="variety" class="required form-control" value="<?php echo e($products->variety); ?>">

        </div>

        <div class="col-sm-1">
        

        </div>


        <div class="col-sm-5">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <label class="input-group-text" for="size">Size</label>
            </div>
            <div class="col-sm-2 form-control" style="background-color: white;">
          <label class="radio-inline px-2"><input type="radio" name="size" id="s0" value="250"  style="padding-left: 5px;"<?php if($products->size=='250'): ?> checked <?php endif; ?>>250ml</label>

          <label class="radio-inline px-2"><input type="radio" name="size" id="s1" value="500"  style="padding-left: 5px;"<?php if($products->size=='500'): ?> checked <?php endif; ?>>500ml</label>
        
          <label class="radio-inline px-2"><input type="radio" name="size" id="s2" value="1000" style="padding-left: 5px;"<?php if($products->size=='1000'): ?> checked <?php endif; ?>>1.0L</label>

          <label class="radio-inline px-2"><input type="radio" name="size" id="s3" value="1500" style="padding-left: 5px;"<?php if($products->size=='1500'): ?> checked <?php endif; ?>>1.5L</label>

          <label class="radio-inline px-2"><input type="radio" name="size" id="s4" value="4500" style="padding-left: 5px;"<?php if($products->size=='4500'): ?> checked <?php endif; ?>>4.5L</label>
        </div>
          </div>
        </div>

      </div>
    

    <div class="form-group row" style="margin-top: 15px;">
          <label for="stock_status" class="col-sm-2 col-form-label">Status</label>
          <div class="col-sm-5">
            <div class="form-control" style="background-color: white;">
            <label class="radio-inline"><input type="radio" name="stock_status" id="r1" value="Available"<?php if($products->stock_status=='Available'): ?> checked <?php endif; ?>> Available</label>
            
            <label class="radio-inline"><input type="radio" name="stock_status" id="r2" value="Sold Out"<?php if($products->stock_status=='Sold Out'): ?> checked <?php endif; ?>>Sold Out</label>
            </div>
           </div>
          

          <div class="col-sm-5">
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <label class="input-group-text" for="price">Product Price(GH&#8373;)</label>
              </div>
              <input type="text" name="price" id="price" class="form-control" value="<?php echo e($products->price); ?>">
            </div>
          </div>

        </div>

        <div class="form-group row">
       
       <div class="col-sm-2 col-form-label">
       <h5 >Description</h5>
       <div class="btn btn-warning" id="add">
       Add
       </div>
       </div>
       <div class="col-sm-10" >
         <ul id="description">
          <?php $__currentLoopData = $productdescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li style="margin-bottom: 20px;" id="item-0">
           <div class="form-group row">
             <div class="col-sm-11">
             <input class="form-control" id="description-0" type="text" name="old_description[]" value="<?php echo e($description->content); ?>">
             <input name="old_description_id[]" type="hidden" value="<?php echo e($description->id); ?>">
             </div>
             
             <div class="col-sm-1">
             <form action=""></form>
            <form action="/dashboard/product/descriptiondelete" method="GET">
              <?php echo csrf_field(); ?>
            <input name="id" type="hidden" value="<?php echo e($description->id); ?>">
              <button type="submit" class="btn btn-danger">
              Delete
              </button>
            </form>
             </div>
                      
           </div>            
         </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
       </div>

     </div>

      

      <button type="submit" class="btn btn-success center-block">
        Update
      </button>
      </div>

      </div>
</form>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    console.log(document.getElementById('img'))

    document.getElementById('img').onclick=(e)=>{
    console.log('here')
    document.getElementById('img').value=null;
  }
  
  document.getElementById('img').onchange=(e)=>{
    console.log(e.target.value.split('/'))
    document.getElementById('old_img').value=e.target.value.split('\\')[2];
  }

  let inputs=[];
    let add = document.getElementById('add');
    let ul = document.getElementById('description')
    let noLists = ul.getElementsByTagName('li').length;
    
    add.onclick=()=>{
      let lis = ul.getElementsByTagName('li');
      inputs=[];
    for(let i=0;i<lis.length;i++){
      const ip =lis[i].getElementsByClassName('row')[0].getElementsByClassName('col-sm-11')[0].querySelector('input');
      inputs.push(
        {id:ip.id,
          value:ip.value
      })
    }

      ul.insertAdjacentHTML('beforeend',
      `
      <li style="margin-bottom: 20px;" id="item-${noLists}">
            <div class="form-group row">
              <div class="col-sm-11">
              <input class="form-control" id="perks-${noLists}" type="text" name="description[]">
              </div>
              <div class="col-sm-1 btn btn-danger del" id="${noLists}">
              Delete
              </div>            
            </div>            
          </li>
      `)
      //add ondel listener
      let del = document.getElementById(`${noLists}`);
      del.onclick=(e)=>{
        document.getElementById(`item-${e.target.id}`).remove();
      }
      noLists+=1;

      
    }
})
  
</script>
       
      

    


<?php echo $__env->make('layouts.nafs_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>