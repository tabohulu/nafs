<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<!-- <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script> -->
<script type="text/javascript" src="/js/jquery-ui/jquery-ui.min.js"></script>


<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->

    
    
    

    
    <?php echo $__env->yieldPushContent('modals'); ?><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/components/common/js.blade.php ENDPATH**/ ?>