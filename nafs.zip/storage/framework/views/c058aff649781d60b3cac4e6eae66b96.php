<!-- Footer Start -->
<footer>
        <div class="footer-content">
            <p>&copy; 2023 NAFS</p>
        </div>
    </footer>
    <!-- Footer End --><?php /**PATH C:\Users\Bohulu\Documents\nafs\resources\views/components/common/footer.blade.php ENDPATH**/ ?>