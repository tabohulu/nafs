<!DOCTYPE html>
<html lang="en">
@include('components.common.head')
  <body>
    <main>
    @include('components.common.footer')
    </main>
    @include('components.common.js')
  </body>
</html>
