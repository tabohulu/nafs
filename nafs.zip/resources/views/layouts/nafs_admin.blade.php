<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@include('components.common.head')
<body>
    <main>
    </main>
    @include('components.common.js')
  </body>
</html>
