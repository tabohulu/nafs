@extends('layouts.hc')
  @include('components.nav.navbar2')
  <div id="calendar"></div>
  @include('components.common.appoint')
  


   