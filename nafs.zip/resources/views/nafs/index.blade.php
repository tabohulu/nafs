  @extends('layouts.nafs')
  @include('layouts.navigation_main')

    <!-- Hero Start -->
    <section class="product">
            <img src="product-image.jpg" alt="Product Name">
            <h2>Product Name</h2>
            <p class="price">$99.99</p>
            <button class="add-to-cart">Add to Cart</button>
        </section>
    
    
    <!-- Team End -->

    

   

    

   
  

  

