@extends('layouts.nafs')
@include('layouts.navigation_main')

