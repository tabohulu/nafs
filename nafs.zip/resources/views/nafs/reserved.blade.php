@extends('layouts.hc')
@include('components.nav.navbar2')


    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h3 class="d-inline-block text-primary text-uppercase border-bottom border-5">予約完了しました。</h3>

                
                <a href="/">ホームページへ</a>
                <!-- <h1 class="display-4">自由にご連絡ください</h1> -->
            </div>
        </div>
    </div>
    <!-- Contact End -->


    