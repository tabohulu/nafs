<!-- Footer Start -->
<footer>
        <div class="footer-content">
            <p>&copy; 2023 NAFS</p>
        </div>
    </footer>
    <!-- Footer End -->